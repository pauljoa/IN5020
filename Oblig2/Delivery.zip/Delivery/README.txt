To run program:

java -jar accountReplica.jar <IP-address> <group name> <number of replicas> <input file name (optional)>

The port is set to 8080 as the assignment doesn't specify that the port number should be an option

When the jar file is running, you won't be able to see what you type in the command window before after you have pressed the enter button.