package client;

public enum State {
	Connecting,
	Awaiting,
	Running,
	Sending,
	Receiving,
	Exiting
}
